## PWA works as it allows a website be able to download directly from browser.
# it works simply by just running the code on live server in VS code and clicking the doiwnload pop-up icon in search bar as you load the website in browser.

-> the offline is having issue else is working perfectly.

<!--
Name: M.S. Tomar
Modified on: 10 April 2022 22:29:51
-->